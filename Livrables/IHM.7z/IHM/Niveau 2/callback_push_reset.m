%% Fonction pour redemarrer le match

function callback_push_reset(hObject,eventdata,f)

% Reset the match
reset_jeu(f)

end