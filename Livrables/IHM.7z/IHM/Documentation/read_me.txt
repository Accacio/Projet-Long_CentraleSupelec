16/06/2017

La fonction principale de cr�ation de l'IHM est: 
f = creation_IHM;
On peut executer aussi: script_IHM .
Ce script est juste pour registrer quelques fonctions principales de l'IHM.

La documentation d'algorithme de l'IHM est dans le fichier Documentation. Ils sont les documents:
Diagramme_fonctions.pdf
script_IHM.pdf